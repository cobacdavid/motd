from setuptools import setup, find_packages

setup(
    name='motd',
    version='1.0',
    description='récupération infos Mathematicians Of The Day\nhttp://mathshistory.st-andrews.ac.uk/Day_files/Year.html',
    url='https://twitter.com/david_cobac',
    author='David COBAC',
    author_email='david.cobac@gmail.com',
    license='CC-BY-NC-SA',
    packages=find_packages()
)
